insert into EQUIPE values(1,1,3);

insert into EQUIPE values(2,1,4);





insert into EQUIPE values(3,1,18);
insert into EQUIPE values(4,0,19);







insert into EQUIPE values(5,0,27);


insert into EQUIPE values(6,1,31);

insert into EQUIPE values(7,1,31);
insert into EQUIPE values(8,0,33);


insert into EQUIPE values(9,1,36);


insert into EQUIPE values(10,0,39);

insert into EQUIPE values(11,0,40);
insert into EQUIPE values(12,1,42);





insert into EQUIPE values(13,1,52);






insert into EQUIPE values(14,0,57);

insert into EQUIPE values(15,0,57);


insert into EQUIPE values(16,1,61);





insert into EQUIPE values(17,1,72);
insert into EQUIPE values(18,0,72);
insert into EQUIPE values(19,1,73);
insert into EQUIPE values(20,0,78);

insert into EQUIPE values(21,0,81);
insert into EQUIPE values(22,1,81);

insert into EQUIPE values(23,1,82);

insert into EQUIPE values(24,1,83);







insert into EQUIPE values(25,1,84);


insert into EQUIPE values(26,0,87);




insert into EQUIPE values(27,1,94);

insert into EQUIPE values(28,1,101);

insert into EQUIPE values(29,1,106);
insert into EQUIPE values(30,0,107);

insert into EQUIPE values(31,0,107);

insert into EQUIPE values(32,0,110);
insert into EQUIPE values(33,1,113);
insert into EQUIPE values(34,0,114);


insert into EQUIPE values(35,1,117);
insert into EQUIPE values(36,0,119);
