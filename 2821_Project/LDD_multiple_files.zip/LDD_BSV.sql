insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(1,41,'1');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(2,12,'2');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(3,82,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(4,80,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(5,71,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(6,81,'');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(7,34,'4');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(8,68,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(9,48,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(10,73,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(11,28,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(12,20,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(13,74,'');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(14,26,'5');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(15,24,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(16,4,'6');



insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(17,21,'8');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(18,51,'');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(19,25,'');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(20,47,'10');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(21,76,'12');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(22,77,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(23,43,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(24,22,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(25,67,'');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(26,5,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(27,78,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(28,6,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(29,70,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(30,91,'');



insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(31,17,'15');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(32,7,'');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(33,46,'16');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(34,32,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(35,14,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(36,94,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(37,79,'');




insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(38,99,'20');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(39,86,'22');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(40,42,'23');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(41,59,'24');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(42,45,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(43,3,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(44,56,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(45,2,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(46,93,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(47,53,'');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(48,36,'25');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(49,39,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(50,37,'26');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(51,38,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(52,55,'');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(53,69,'');



insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(54,27,'28');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(55,96,'30');

insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(56,57,'31');



insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(57,66,'34');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(58,85,'');


insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(59,8,'36');
insert into BSV(BSV_ID, BSV_BENEVOLE_ID, BSV_EQUIPE_ID) values(60,87,'');
