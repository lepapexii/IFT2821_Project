DROP TABLE SECTEUR CASCADE constraints;
DROP TABLE EQUIPE CASCADE constraints;
DROP TABLE BENEVOLE CASCADE constraints;
DROP TABLE BAV CASCADE constraints;
DROP TABLE BSV CASCADE constraints;
DROP TABLE CLIENT CASCADE constraints;
DROP TABLE SERVICE CASCADE constraints;


CREATE TABLE SECTEUR
(
	SECTEUR_ID INT not null,
	PREFIX_POSTAL VARCHAR2(3),
	NOM VARCHAR2(50),
	ZONE VARCHAR2(50),
	constraint SECTEUR_PK primary key (SECTEUR_ID),
	constraint SECTEUR_PREFIX_POSTAL_UINDEX unique (PREFIX_POSTAL)
)
;

CREATE TABLE EQUIPE
(
	EQUIPE_ID INT not null,
	ETAT INT,
	EQUIPE_SECTEUR_ID INT,
	constraint EQUIPE_PK primary key (EQUIPE_ID),
	constraint EQUIPE_EQUIPE_SECTEUR_ID_FK foreign key (EQUIPE_SECTEUR_ID) references SECTEUR(SECTEUR_ID) on delete cascade
)
;

CREATE TABLE BENEVOLE
(
	BENEVOLE_ID INT not null,
	NOM VARCHAR2(20),
	PRENOM VARCHAR2(20),
	CODE_POSTAL VARCHAR2(6) not null,
	BENEVOLE_SECTEUR_ID INT,
	constraint BENEVOLE_PK primary key (BENEVOLE_ID),
	constraint BNV_BENEVOLE_SECTEUR_ID_FK foreign key (BENEVOLE_SECTEUR_ID) references SECTEUR(SECTEUR_ID) on delete cascade
)
;

CREATE TABLE BAV
(
	BAV_ID INT not null,
	BAV_BENEVOLE_ID INT,
	BAV_EQUIPE_ID INT,
	constraint BAV_PK primary key (BAV_ID),
	constraint BAV_BAV_BENVOLE_ID_FK foreign key (BAV_BENEVOLE_ID) references BENEVOLE(BENEVOLE_ID) on delete cascade,
	constraint BAV_BAV_EQUIPE_ID_FK foreign key (BAV_EQUIPE_ID) references EQUIPE(EQUIPE_ID) on delete cascade
)
;

CREATE TABLE BSV
(
	BSV_ID INT not null,
	BSV_BENEVOLE_ID INT,
	BSV_EQUIPE_ID INT,
	constraint BSV_PK primary key (BSV_ID),
	constraint BSV_BSV_BENVOLE_ID_FK foreign key (BSV_BENEVOLE_ID) references BENEVOLE(BENEVOLE_ID) on delete cascade,
	constraint BSV_BSV_EQUIPE_ID_FK foreign key (BSV_EQUIPE_ID) references EQUIPE(EQUIPE_ID) on delete cascade
)
;

CREATE TABLE CLIENT
(
	CLIENT_ID INT not null,
	NOM VARCHAR2(20),
	PRENOM VARCHAR2(20),
	CODE_POSTAL VARCHAR2(6) not null,
	CLIENT_SECTEUR_ID INT,
	constraint CLIENT_PK primary key (CLIENT_ID),
	constraint CLIENT_CLIENT_SECTEUR_ID_FK foreign key (CLIENT_SECTEUR_ID) references SECTEUR(SECTEUR_ID) on delete cascade
)
;

CREATE TABLE SERVICE
(
	SERVICE_ID INT not null,
	TYPE VARCHAR2(20),
	"DATE" VARCHAR2(20),
	INCIDENT VARCHAR2(40),
	STATUS INT,
	SERVICE_CLIENT_ID INT,
	SERVICE_EQUIPE_ID INT,
	SERVICE_SECTEUR_ID INT,
	constraint SERVICE_PK primary key (SERVICE_ID),
	constraint SERVICE_SERVICE_CLIENT_ID_FK foreign key (SERVICE_CLIENT_ID) references CLIENT(CLIENT_ID) on delete cascade,
	constraint SERVICE_SERVICE_EQUIPE_ID_FK foreign key (SERVICE_EQUIPE_ID) references EQUIPE(EQUIPE_ID) on delete cascade,
	constraint SERVICE_SERVICE_SECTEUR_ID_FK foreign key (SERVICE_SECTEUR_ID) references SECTEUR(SECTEUR_ID) on delete cascade
)
;
