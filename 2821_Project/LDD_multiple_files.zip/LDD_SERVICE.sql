insert into SERVICE values(1,'général','2019/04/08','aucun incident',1,2,'1',3);

insert into SERVICE values(2,'hygiène','2019/04/08','aucun incident',1,3,'2',4);





insert into SERVICE values(3,'cuisine','2019/04/08','insatisfait du service rendu',1,12,'3',18);
insert into SERVICE values(4,'cuisine','2019/01/23','insatisfait du service rendu',2,13,'4',19);







insert into SERVICE values(5,'technologie','2018/05/10','retard',2,20,'5',27);


insert into SERVICE values(6,'général','2019/04/08','retard',1,24,'6',31);

insert into SERVICE values(7,'ménage','2019/04/08','aucun incident',1,25,'7',31);
insert into SERVICE values(8,'transport','2019/02/15','aucun incident',2,27,'8',33);


insert into SERVICE values(9,'paperasse','2019/04/08','retard',1,29,'9',36);


insert into SERVICE values(10,'épicerie','2019/03/21','aucun incident',2,30,'10',39);

insert into SERVICE values(11,'ménage','2017/10/26','endommagement de bien',2,31,'11',40);
insert into SERVICE values(12,'hygiène','2019/04/08','aucun incident',1,32,'12',42);





insert into SERVICE values(13,'transport','2019/04/08','aucun incident',1,36,'13',52);






insert into SERVICE values(14,'épicerie','2018/12/23','aucun incident',2,39,'14',57);

insert into SERVICE values(15,'épicerie','2018/06/21','retard',2,40,'15',57);


insert into SERVICE values(16,'cuisine','2019/04/08','insatisfait du service rendu',1,42,'16',61);





insert into SERVICE values(17,'paperasse','2019/04/08','insatisfait du service rendu',1,47,'17',72);
insert into SERVICE values(18,'hygiène','2019/01/10','aucun incident',2,48,'18',72);
insert into SERVICE values(19,'technologie','2019/04/08','insatisfait du service rendu',1,49,'19',73);
insert into SERVICE values(20,'hygiène','2019/01/16','aucun incident',2,53,'20',78);

insert into SERVICE values(21,'hygiène','2018/03/08','endommagement de bien',2,57,'21',81);
insert into SERVICE values(22,'épicerie','2019/04/08','comportement du bénévole',1,58,'22',81);

insert into SERVICE values(23,'technologie','2019/04/08','aucun incident',1,59,'23',82);

insert into SERVICE values(24,'ménage','2019/04/08','endommagement de bien',1,60,'24',83);







insert into SERVICE values(25,'général','2019/04/08','comportement du bénévole',1,69,'25',84);


insert into SERVICE values(26,'épicerie','2017/09/29','aucun incident',2,72,'26',87);




insert into SERVICE values(27,'transport','2019/04/08','aucun incident',1,77,'27',94);

insert into SERVICE values(28,'technologie','2019/04/08','endommagement de bien',1,83,'28',101);

insert into SERVICE values(29,'ménage','2019/04/08','retard',1,86,'29',106);
insert into SERVICE values(30,'cuisine','2018/09/02','aucun incident',2,87,'30',107);

insert into SERVICE values(31,'hygiène','2017/05/09','endommagement de bien',2,88,'31',107);

insert into SERVICE values(32,'transport','2018/08/20','aucun incident',2,89,'32',110);
insert into SERVICE values(33,'paperasse','2019/04/08','retard',1,90,'33',113);
insert into SERVICE values(34,'épicerie','2018/11/23','insatisfait du service rendu',2,91,'34',114);


insert into SERVICE values(35,'général','2019/04/08','aucun incident',1,64,'',101);
insert into SERVICE values(36,'épicerie','2019/04/08','aucun incident',2,100,'',70);
insert into SERVICE values(37,'cuisine','2019/04/08','comportement du bénévole',0,91,'',98);
insert into SERVICE values(38,'cuisine','2019/04/08','comportement du bénévole',0,40,'',93);
insert into SERVICE values(39,'transport','2019/04/08','aucun incident',0,40,'',63);
insert into SERVICE values(40,'ménage','2019/04/08','endommagement de bien',0,85,'',64);
insert into SERVICE values(41,'transport','2019/04/08','insatisfait du service rendu',0,38,'',60);
insert into SERVICE values(42,'hygiène','2019/04/08','aucun incident',0,47,'',60);
insert into SERVICE values(43,'technologie','2019/04/08','comportement du bénévole',0,79,'',13);
insert into SERVICE values(44,'hygiène','2019/04/08','aucun incident',0,68,'',39);
insert into SERVICE values(45,'cuisine','2019/04/08','retard',0,39,'',95);
insert into SERVICE values(46,'hygiène','2019/04/08','aucun incident',0,42,'',40);
insert into SERVICE values(47,'cuisine','2019/04/08','retard',0,92,'',13);
insert into SERVICE values(48,'paperasse','2019/04/08','aucun incident',0,66,'',97);
insert into SERVICE values(49,'épicerie','2019/04/08','endommagement de bien',0,48,'',122);
insert into SERVICE values(50,'épicerie','2019/04/08','retard',0,27,'',53);
insert into SERVICE values(51,'ménage','2019/04/08','aucun incident',0,38,'',92);
insert into SERVICE values(52,'hygiène','2019/04/08','aucun incident',0,27,'',104);
insert into SERVICE values(53,'hygiène','2019/04/08','aucun incident',0,90,'',90);
insert into SERVICE values(54,'cuisine','2019/04/08','retard',0,98,'',55);
insert into SERVICE values(55,'ménage','2019/04/08','aucun incident',0,70,'',59);
insert into SERVICE values(56,'hygiène','2019/04/08','aucun incident',0,100,'',116);
insert into SERVICE values(57,'technologie','2019/04/08','aucun incident',0,87,'',99);
insert into SERVICE values(58,'transport','2019/04/08','insatisfait du service rendu',0,64,'',80);
insert into SERVICE values(59,'hygiène','2019/04/08','aucun incident',0,59,'',76);
insert into SERVICE values(60,'épicerie','2019/04/08','aucun incident',0,63,'',26);
insert into SERVICE values(61,'paperasse','2019/04/08','insatisfait du service rendu',0,79,'',83);
insert into SERVICE values(62,'cuisine','2019/04/08','aucun incident',0,46,'',105);
insert into SERVICE values(63,'hygiène','2019/04/08','endommagement de bien',0,36,'',72);
insert into SERVICE values(64,'paperasse','2019/04/08','aucun incident',0,40,'',51);
insert into SERVICE values(65,'technologie','2019/04/08','endommagement de bien',0,86,'',62);
insert into SERVICE values(66,'paperasse','2019/04/08','comportement du bénévole',0,16,'',78);
insert into SERVICE values(67,'hygiène','2019/04/08','aucun incident',0,55,'',32);
insert into SERVICE values(68,'paperasse','2019/04/08','aucun incident',0,53,'',113);
insert into SERVICE values(69,'transport','2019/04/08','aucun incident',0,1,'',75);
insert into SERVICE values(70,'paperasse','2019/04/08','comportement du bénévole',0,76,'',14);
insert into SERVICE values(71,'transport','2019/04/08','aucun incident',0,92,'',67);
insert into SERVICE values(72,'technologie','2019/04/08','aucun incident',0,58,'',80);
insert into SERVICE values(73,'cuisine','2019/04/08','endommagement de bien',0,9,'',62);
insert into SERVICE values(74,'général','2019/04/08','aucun incident',0,67,'',108);
insert into SERVICE values(75,'transport','2019/04/08','endommagement de bien',0,44,'',97);
insert into SERVICE values(76,'cuisine','2019/04/08','retard',0,8,'',101);
insert into SERVICE values(77,'épicerie','2019/04/08','endommagement de bien',0,42,'',107);
insert into SERVICE values(78,'cuisine','2019/04/08','aucun incident',0,56,'',91);
insert into SERVICE values(79,'transport','2019/04/08','insatisfait du service rendu',0,7,'',25);
insert into SERVICE values(80,'hygiène','2019/04/08','insatisfait du service rendu',0,46,'',96);
insert into SERVICE values(81,'hygiène','2019/04/08','comportement du bénévole',0,24,'',113);
insert into SERVICE values(82,'paperasse','2019/04/08','endommagement de bien',0,78,'',91);
insert into SERVICE values(83,'paperasse','2019/04/08','endommagement de bien',0,86,'',109);
insert into SERVICE values(84,'général','2019/04/08','aucun incident',0,96,'',52);
insert into SERVICE values(85,'hygiène','2019/04/08','insatisfait du service rendu',0,91,'',19);
insert into SERVICE values(86,'transport','2019/04/08','endommagement de bien',0,54,'',2);
insert into SERVICE values(87,'cuisine','2019/04/08','comportement du bénévole',0,64,'',78);
insert into SERVICE values(88,'cuisine','2019/04/08','aucun incident',0,78,'',71);
insert into SERVICE values(89,'général','2019/04/08','insatisfait du service rendu',0,97,'',8);
insert into SERVICE values(90,'ménage','2019/04/08','aucun incident',0,61,'',108);
insert into SERVICE values(91,'ménage','2019/04/08','aucun incident',0,17,'',18);
insert into SERVICE values(92,'hygiène','2019/04/08','endommagement de bien',0,49,'',5);
insert into SERVICE values(93,'transport','2019/04/08','retard',0,83,'',121);
insert into SERVICE values(94,'ménage','2019/04/08','comportement du bénévole',0,68,'',16);
insert into SERVICE values(95,'transport','2019/04/08','insatisfait du service rendu',0,82,'',67);
insert into SERVICE values(96,'épicerie','2019/04/08','endommagement de bien',0,42,'',117);
insert into SERVICE values(97,'transport','2019/04/08','aucun incident',0,52,'',83);
insert into SERVICE values(98,'technologie','2019/04/08','insatisfait du service rendu',0,22,'',45);
insert into SERVICE values(99,'ménage','2019/04/08','endommagement de bien',0,7,'',66);
insert into SERVICE values(100,'général','2019/04/08','comportement du bénévole',0,46,'',28);
